<?php

namespace App\Http\Controllers;

use App\Http\Resources\NewsListResource;
use App\Http\Resources\WebStorySliderDataResource;
use App\Models\News;
use App\Models\WebStory;
use App\Services\News\CategoryIdsByChildRecursiveQuery;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class WebStoryController extends Controller
{
    public function sliderData(): AnonymousResourceCollection
    {
        $data = WebStory::orderByDesc('created_at')
            ->with(['items', 'news'])
            ->limit(10)
            ->get();

        return WebStorySliderDataResource::collection($data);
    }

    /**
     * @return array<string, mixed>
     */
    public function sliderDetails(string $hash_key): array
    {
        $webStory = WebStory::orderByDesc('created_at')
            ->with(['items:title,image,web_story_id', 'news.category.parentRecursive'])
            ->limit(10)
            ->where('hash_key', $hash_key)
            ->firstOrFail();

        return [
            'id' => $webStory->id,
            'hash_key' => $webStory->hash_key,
            'items' => $webStory->items,
            'news' => NewsListResource::make($webStory->news),
        ];
    }

    public function sportsWebHistory(CategoryIdsByChildRecursiveQuery $categoryIdsByChildRecursiveQuery): AnonymousResourceCollection
    {
        $sportsCategoryIds = $categoryIdsByChildRecursiveQuery->handle(['sports']);

        $data = News::whereHas('webStory')
            ->whereIn('category_id', $sportsCategoryIds)
            ->with(['webStory', 'webStory.items:title,image,web_story_id'])
            ->orderByDesc('created_at')
            ->limit(10)
            ->get()
            ->pluck('webStory');

        return WebStorySliderDataResource::collection($data);
    }
}
