<?php

namespace App\Http\Controllers;

use App\Models\District;
use App\Models\Division;
use App\Models\Upazila;
use Illuminate\Database\Eloquent\Collection;

class GeoLocationController extends Controller
{
    public function divisions(): Collection
    {
        return Division::orderBy('name')->get(['name', 'slug']);
    }

    /**
     * @return array<string, mixed>
     */
    public function districts(string $divisionSlug): array
    {
        $division = Division::where('slug', $divisionSlug)->firstOrFail();
        $districts = District::where('division_id', $division->id)
            ->orderBy('name')
            ->get(['name', 'slug']);

        return [
            'division' => ['name' => $division->name, 'slug' => $division->slug],
            'items' => $districts,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function upazilas(string $districtSlug): array
    {
        $district = District::with('division:id,name,slug')->where('slug', $districtSlug)->firstOrFail();
        $upazilas = Upazila::where('district_id', $district->id)
            ->orderBy('name')
            ->get(['name', 'slug']);

        return [
            'division' => ['name' => $district->division->name, 'slug' => $district->division->slug],
            'district' => ['name' => $district->name, 'slug' => $district->slug],
            'items' => $upazilas,
        ];
    }
}
