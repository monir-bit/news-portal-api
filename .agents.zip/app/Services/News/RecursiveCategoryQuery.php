<?php

namespace App\Services\News;

use App\Models\Category;
use Illuminate\Database\Eloquent\Collection;

class RecursiveCategoryQuery
{
    /**
     * @return Collection<int, Category>
     */
    public function handle(): Collection
    {
        $printCategoryIds = app(CategoryAllChildrenIdsQuery::class)->handle('print');

        return Category::query()
            ->whereNotIn('id', $printCategoryIds)
            ->whereNull('parent_id')
            ->where('visible', true)
            ->orderBy('position')
            ->with(['childrenRecursive'])
            ->select('id', 'parent_id', 'name', 'slug')
            ->get();
    }
}
