<?php

namespace App\Services\News;

use App\Http\Resources\NewsListResource;
use App\Models\LayoutSection;
use App\Models\LayoutSectionNews;

class ThankNewsQuery
{
    /**
     * @return array<string, mixed>
     */
    public function handle(): array
    {
        $sectionSlug = 'thanks';

        $layoutSection = LayoutSection::where('slug', $sectionSlug)->select('id')->first();
        if (! $layoutSection) {
            return [];
        }

        $section = LayoutSectionNews::query()
            ->select(['layout_section_news.id', 'layout_section_news.news_id', 'layout_section_news.position'])
            ->join('news', 'news.id', '=', 'layout_section_news.news_id')
            ->with([
                'news' => fn ($q) => $q->select(NewsListResource::NEWS_COLUMNS),
                'news.liveNews' => fn ($q) => $q->select(NewsListResource::LIVE_NEWS_COLUMNS),
                'news.thankNews',
                'news.category' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
                'news.category.parentRecursive' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
                'news.category.parentRecursive.parentRecursive' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
            ])
            ->where('layout_section_news.layout_section_id', $layoutSection->id)
            ->whereNull('news.deleted_at')
            ->where('news.published', true)
            ->orderBy('layout_section_news.position', 'ASC')
            ->first();

        if (! $section || ! $section->news) {
            return [];
        }

        return [
            'meta' => $section->news->thankNews?->toArray(),
            'news' => NewsListResource::make($section->news)->resolve(),
        ];
    }
}
