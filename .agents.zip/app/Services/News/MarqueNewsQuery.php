<?php

namespace App\Services\News;

use App\Http\Resources\NewsListResource;
use App\Models\MarqueNews;
use App\Models\News;

class MarqueNewsQuery
{
    /**
     * @return array<int, mixed>
     */
    public function handle(): array
    {
        $news = News::query()
            ->select(NewsListResource::NEWS_COLUMNS)
            ->whereIn('id', MarqueNews::query()->select('news_id'))
            ->where('published', true)
            ->with([
                'category' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
                'category.parentRecursive' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
                'category.parentRecursive.parentRecursive' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
            ])
            ->orderByDesc('date')
            ->limit(10)
            ->get();

        return NewsListResource::collection($news)->resolve();
    }
}
