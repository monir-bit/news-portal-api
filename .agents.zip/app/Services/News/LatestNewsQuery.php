<?php

namespace App\Services\News;

use App\Http\Resources\NewsListResource;
use App\Models\LatestNews;
use App\Support\PortalDateHelper;

class LatestNewsQuery
{
    /**
     * @return array<int, mixed>
     */
    public function handle(int $offset = 0, int $limit = 15): array
    {
        $news = LatestNews::query()
            ->select(['latest_news.id', 'latest_news.news_id', 'latest_news.position'])
            ->join('news', 'latest_news.news_id', '=', 'news.id')
            ->with([
                'news' => fn ($q) => $q->select(NewsListResource::NEWS_COLUMNS),
                'news.category' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
                'news.category.parentRecursive' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
                'news.category.parentRecursive.parentRecursive' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
            ])
            ->where('news.published', true)
            ->whereBetween('news.date', [
                PortalDateHelper::todayStart(),
                PortalDateHelper::todayEnd(),
            ])
            ->orderByDesc('news.date')
            ->offset($offset)
            ->limit($limit)
            ->get()
            ->pluck('news');

        return NewsListResource::collection($news)->resolve();
    }
}
