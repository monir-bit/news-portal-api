<?php

namespace App\Services\News;

use App\Http\Resources\NewsListResource;
use App\Models\News;
use App\Models\NewsRead;
use App\Support\PortalDateHelper;

class MostReadNewsQuery
{
    /**
     * @return array<int, mixed>
     */
    public function handle(): array
    {
        $mostReadIds = NewsRead::query()
            ->select('news_reads.news_id')
            ->join('news', 'news.id', '=', 'news_reads.news_id')
            ->where('news.published', true)
            ->whereBetween('news.date', [
                PortalDateHelper::subDay(),
                PortalDateHelper::now(),
            ])
            ->groupBy('news_reads.news_id')
            ->orderByRaw('COUNT(*) DESC')
            ->limit(15)
            ->pluck('news_reads.news_id');

        $news = News::query()
            ->select(NewsListResource::NEWS_COLUMNS)
            ->whereIn('id', $mostReadIds)
            ->with([
                'category' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
                'category.parentRecursive' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
                'category.parentRecursive.parentRecursive' => fn ($q) => $q->select(NewsListResource::CATEGORY_COLUMNS),
            ])
            ->get()
            ->sortBy(fn ($news) => $mostReadIds->search($news->id))
            ->values();

        return NewsListResource::collection($news)->resolve();
    }
}
