---
name: scout-development
description: "Develops full-text search with Laravel Scout. Activates when installing or configuring Scout; choosing a search engine (Algolia, Meilisearch, Typesense, Database, Collection); adding the Searchable trait to models; customizing toSearchableArray or searchableAs; importing or flushing search indexes; writing search queries with where clauses, pagination, or soft deletes; configuring index settings; troubleshooting search results; or when the user mentions Scout, full-text search, search indexing, or search engines in a Laravel project. Make sure to use this skill whenever the user works with search functionality in Laravel, even if they don't explicitly mention Scout."
license: MIT
metadata:
  author: laravel
---
@php
/** @var \Laravel\Boost\Install\GuidelineAssist $assist */
@endphp
# Scout Full-Text Search

## Documentation First

**Always use ___SINGLE_BACKTICK___search-docs___SINGLE_BACKTICK___ before writing Scout code.** The documentation covers every engine, configuration option, and edge case in detail. This skill teaches you how to navigate Scout — the docs have the implementation specifics.

___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___
search-docs(queries: ["Scout installation"], packages: ["laravel/framework@12.x"])
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___

The Scout docs live under the ___SINGLE_BACKTICK___laravel/framework___SINGLE_BACKTICK___ package — not ___SINGLE_BACKTICK___laravel/scout___SINGLE_BACKTICK___.

Effective search patterns:

- Installation & setup: ___SINGLE_BACKTICK___"Scout installation"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout queueing"___SINGLE_BACKTICK___
- Engine setup: ___SINGLE_BACKTICK___"Scout Algolia"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout Meilisearch"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout Typesense"___SINGLE_BACKTICK___
- Model configuration: ___SINGLE_BACKTICK___"Scout configuring searchable data"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout configuring model indexes"___SINGLE_BACKTICK___
- Searching: ___SINGLE_BACKTICK___"Scout searching"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout where clauses"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout pagination"___SINGLE_BACKTICK___
- Indexing: ___SINGLE_BACKTICK___"Scout batch import"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout adding records"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout removing records"___SINGLE_BACKTICK___
- Advanced: ___SINGLE_BACKTICK___"Scout soft deleting"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout customizing engine searches"___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___"Scout custom engines"___SINGLE_BACKTICK___

The docs are organized into these main sections: Installation, Driver Prerequisites, Configuration, Database/Collection Engines, Indexing, Searching, Custom Engines. Use these section names as search anchors.

## When to Apply

Activate this skill when:

- Installing or configuring Scout
- Choosing a search engine for a Laravel application
- Making Eloquent models searchable
- Customizing indexed data or index names
- Writing search queries, filters, or pagination
- Importing or flushing search indexes
- Troubleshooting search results or indexing issues
- Choosing between search engines

## Installation

Before installing, check if Scout is already in the project — look for ___SINGLE_BACKTICK___laravel/scout___SINGLE_BACKTICK___ in ___SINGLE_BACKTICK___composer.json___SINGLE_BACKTICK___ and ___SINGLE_BACKTICK___config/scout.php___SINGLE_BACKTICK___. If already installed, skip to the relevant section (engine configuration, model setup, or searching).

### 1. Install Scout

___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___bash
composer require laravel/scout
{{ $assist->artisanCommand('vendor:publish --provider="Laravel\Scout\ScoutServiceProvider"') }}
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___

### 2. Add the Searchable trait

___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___php
use Illuminate\Database\Eloquent\Model;
use Laravel\Scout\Searchable;

class Post extends Model
{
    use Searchable;
}
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___

This registers a model observer that automatically keeps your search index in sync with Eloquent records.

## Choosing an Engine

Before presenting engine options, check if Scout is already configured in the application:

1. Check ___SINGLE_BACKTICK___.env___SINGLE_BACKTICK___ for ___SINGLE_BACKTICK___SCOUT_DRIVER___SINGLE_BACKTICK___ — if set, the application already has a configured engine.
2. Check ___SINGLE_BACKTICK___config/scout.php___SINGLE_BACKTICK___ for the ___SINGLE_BACKTICK___driver___SINGLE_BACKTICK___ key and any engine-specific settings.
3. Check ___SINGLE_BACKTICK___composer.json___SINGLE_BACKTICK___ for engine SDKs (___SINGLE_BACKTICK___algolia/algoliasearch-client-php___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___meilisearch/meilisearch-php___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___typesense/typesense-php___SINGLE_BACKTICK___).

If an engine is already configured, skip the engine selection step and work with the existing setup. Only present the engine comparison if Scout is not yet installed or the user explicitly wants to switch engines.

When no engine is configured, present these options and let the user decide — never choose for them.

| Engine | Type | Best For | Tradeoffs |
|--------|------|----------|-----------|
| **Database** | Built-in | Typical applications, simple search | No external deps. MySQL/PostgreSQL only. LIKE + full-text indexes. No typo tolerance. |
| **Collection** | Built-in | Local dev, tiny datasets (<500 records) | Loads all records into memory. Most portable but least efficient. |
| **Algolia** | Hosted SaaS | Advanced search without managing infra | Typo tolerance, analytics, faceting. Paid service. No self-hosting. |
| **Meilisearch** | Self-hosted / Cloud | Teams wanting infrastructure control | Fast, open-source. Self-hostable or cloud. Requires filterable attribute config. |
| **Typesense** | Self-hosted / Cloud | Keyword, semantic, geo, vector search | Open-source. Self-hostable or cloud. Strict schema requirements. |

After the user chooses, use ___SINGLE_BACKTICK___search-docs___SINGLE_BACKTICK___ for that engine's prerequisites and configuration.

Set the engine in ___SINGLE_BACKTICK___.env___SINGLE_BACKTICK___:

___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___ini
SCOUT_DRIVER=database
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___

For third-party engines (Algolia, Meilisearch, Typesense): install their PHP SDK and strongly consider enabling queue support in ___SINGLE_BACKTICK___config/scout.php___SINGLE_BACKTICK___ for production.

## Model Configuration

Use ___SINGLE_BACKTICK___search-docs___SINGLE_BACKTICK___ for full configuration details. Key customization points:

___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___php
// Control what data gets indexed
public function toSearchableArray(): array
{
    return [
        'id' => $this->id,
        'title' => $this->title,
        'body' => $this->body,
    ];
}

// Custom index name (no effect with database engine)
public function searchableAs(): string
{
    return 'posts_index';
}
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___

For Algolia/Meilisearch/Typesense: configure index settings (filterable, sortable, searchable attributes) in ___SINGLE_BACKTICK___config/scout.php___SINGLE_BACKTICK___, then sync:

___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___bash
{{ $assist->artisanCommand('scout:sync-index-settings') }}
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___

## Searching

Basic patterns:

___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___php
// Simple search
$results = Model::search('query')->get();

// With filtering
$results = Model::search('query')->where('status', 'active')->get();

// Paginated
$results = Model::search('query')->paginate(15);

// Eager load relationships on results
$results = Model::search('query')
    ->query(fn ($q) => $q->with('category'))
    ->get();

// Raw engine results
$results = Model::search('query')->raw();
___SINGLE_BACKTICK______SINGLE_BACKTICK______SINGLE_BACKTICK___

Use ___SINGLE_BACKTICK___search-docs___SINGLE_BACKTICK___ for advanced querying — ___SINGLE_BACKTICK___whereIn___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___whereNotIn___SINGLE_BACKTICK___, soft deletes, custom indexes, and engine-specific options.

## Key Artisan Commands

| Command | Purpose |
|---------|---------|
| ___SINGLE_BACKTICK___{{ $assist->artisanCommand('scout:import "App\\Models\\Post"') }}___SINGLE_BACKTICK___ | Import model records into search index |
| ___SINGLE_BACKTICK___{{ $assist->artisanCommand('scout:queue-import "App\\Models\\Post"') }}___SINGLE_BACKTICK___ | Import via queued jobs (large datasets) |
| ___SINGLE_BACKTICK___{{ $assist->artisanCommand('scout:flush "App\\Models\\Post"') }}___SINGLE_BACKTICK___ | Remove all model records from search index |
| ___SINGLE_BACKTICK___{{ $assist->artisanCommand('scout:sync-index-settings') }}___SINGLE_BACKTICK___ | Sync index settings to the search engine |
| ___SINGLE_BACKTICK___{{ $assist->artisanCommand('scout:index posts') }}___SINGLE_BACKTICK___ | Create a search index |
| ___SINGLE_BACKTICK___{{ $assist->artisanCommand('scout:delete-index posts') }}___SINGLE_BACKTICK___ | Delete a search index |

## Testing

Scout does **not** have a ___SINGLE_BACKTICK___Scout::fake()___SINGLE_BACKTICK___ method. Available approaches:

- **NullEngine** — set ___SINGLE_BACKTICK___SCOUT_DRIVER=null___SINGLE_BACKTICK___ to disable all indexing in tests
- **CollectionEngine** — set ___SINGLE_BACKTICK___SCOUT_DRIVER=collection___SINGLE_BACKTICK___ for in-memory search without external services
- **___SINGLE_BACKTICK___Model::withoutSyncingToSearch(fn() => ...)___SINGLE_BACKTICK___** — temporarily pause indexing in a callback
- **___SINGLE_BACKTICK___Model::disableSearchSyncing()___SINGLE_BACKTICK___** — globally disable syncing in test setUp

Use ___SINGLE_BACKTICK___search-docs___SINGLE_BACKTICK___ for detailed testing patterns.

## Common Pitfalls

- **Meilisearch filterable attributes** — you must configure filterable attributes in ___SINGLE_BACKTICK___config/scout.php___SINGLE_BACKTICK___ under ___SINGLE_BACKTICK___meilisearch.index-settings___SINGLE_BACKTICK___ and run ___SINGLE_BACKTICK___scout:sync-index-settings___SINGLE_BACKTICK___ **before** using ___SINGLE_BACKTICK___where___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___whereIn___SINGLE_BACKTICK___, or ___SINGLE_BACKTICK___whereNotIn___SINGLE_BACKTICK___. Without this, filtering silently returns wrong results.
- **Meilisearch data type casting** — ___SINGLE_BACKTICK___toSearchableArray()___SINGLE_BACKTICK___ must return properly cast values: integers as ___SINGLE_BACKTICK___(int)___SINGLE_BACKTICK___, floats as ___SINGLE_BACKTICK___(float)___SINGLE_BACKTICK___. Wrong types cause silent filter failures.
- **Database engine limitations** — ___SINGLE_BACKTICK___searchableAs()___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___getScoutKey()___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___getScoutKeyName()___SINGLE_BACKTICK___, and ___SINGLE_BACKTICK___shouldBeSearchable()___SINGLE_BACKTICK___ have no effect with the database engine. It queries your actual tables directly.
- **Global scopes break pagination** — search engines are not aware of Eloquent global scopes. Recreate scope constraints using Scout ___SINGLE_BACKTICK___where___SINGLE_BACKTICK___ clauses instead.
- **___SINGLE_BACKTICK___query()___SINGLE_BACKTICK___ is not for filtering** — with third-party engines, the ___SINGLE_BACKTICK___query()___SINGLE_BACKTICK___ callback runs after results are already retrieved. Use Scout ___SINGLE_BACKTICK___where___SINGLE_BACKTICK___ clauses for filtering; use ___SINGLE_BACKTICK___query()___SINGLE_BACKTICK___ only for eager-loading or customizing the Eloquent hydration query.
- **Missing queue configuration** — third-party engines should always have ___SINGLE_BACKTICK___scout.queue___SINGLE_BACKTICK___ enabled in production. Without it, indexing runs synchronously and slows down requests.
- **Typesense schema requirements** — ___SINGLE_BACKTICK___id___SINGLE_BACKTICK___ must be cast as ___SINGLE_BACKTICK___(string)___SINGLE_BACKTICK___ and timestamps as Unix integers (___SINGLE_BACKTICK___$this->created_at->timestamp___SINGLE_BACKTICK___).
- **___SINGLE_BACKTICK___shouldBeSearchable()___SINGLE_BACKTICK___ bypass** — this method only applies via ___SINGLE_BACKTICK___save()___SINGLE_BACKTICK___, ___SINGLE_BACKTICK___create()___SINGLE_BACKTICK___, queries, or relationships. Calling ___SINGLE_BACKTICK___searchable()___SINGLE_BACKTICK___ directly on a model or collection bypasses it entirely.
